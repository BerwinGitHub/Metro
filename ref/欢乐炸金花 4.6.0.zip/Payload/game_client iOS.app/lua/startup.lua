--
-- Created by IntelliJ IDEA.
-- User: Administrator
-- Date: 2017/2/8 0008
-- Time: 下午 12:50
-- To change this template use File | Settings | File Templates.
--

function __G__TRACKBACK__(msg)
    cclog.e("----------------------------------------")
    cclog.e("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog.e(debug.traceback())
    cclog.e("----------------------------------------")
    if device.platform == "ios" or device.platform == "android" then
        local message = msg
        buglyReportLuaException(tostring(message),debug.traceback())
    end
    return msg
end

GAME_RELEASE = true
local fileUtils = cc.FileUtils:getInstance()
fileUtils:setPopupNotify(false)
-- 清除fileCached 避免无法加载新的资源。
fileUtils:purgeCachedEntries()


package.loaded["launcher.launcher"] = nil

if GAME_RELEASE then
	cc.LuaLoadChunksFromZIP("launcher.zip")
end

require("launcher.launcher")

